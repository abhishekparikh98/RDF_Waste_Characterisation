# 1. Ask for user input
user_input = input("Please give your grade in percentages (0-100): ")

# 2. Input Validation (Bonus Points)
# Check if it's a digit and if it's within the valid 0-100 range
if user_input.isdigit() and 0 <= int(user_input) <= 100:
    grade = int(user_input)
    
    # 3. Chained Conditionals to find the Letter Grade
    if grade >= 90:
        letter = "A"
    elif grade >= 80:
        letter = "B"
    elif grade >= 70:
        letter = "C"
    elif grade >= 60:
        letter = "D"
    elif grade >= 50:
        letter = "E"
    else:
        letter = "F"
        
    print(f"Your letter grade is {letter}.")

else:
    # Exit gracefully if input is text or out of range
    print("Please input a digit between 0 and 100.")