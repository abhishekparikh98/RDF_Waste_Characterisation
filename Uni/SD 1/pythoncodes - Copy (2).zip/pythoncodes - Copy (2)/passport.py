from datetime import date

class Passport:
    def __init__(self, first_name, last_name, dob, country, exp_date):
        """
        The constructor: initializes the passport properties.
        Dates are converted from ISO strings to date objects.
        """
        self.first_name = first_name
        self.last_name = last_name
        # Convert ISO strings (YYYY-MM-DD) to date objects
        self.dob = date.fromisoformat(dob)
        self.country = country
        self.exp_date = date.fromisoformat(exp_date)

    def is_valid(self):
        """Returns True if the expiration date is in the future."""
        today = date.today()
        # The passport is valid if the expiration date is strictly after today
        return self.exp_date > today

    def summary(self):
        """Returns a human-readable summary of the passport holder."""
        # Use a ternary operator to decide the validity string
        validity_str = "valid" if self.is_valid() else "invalid"
        
        return (f"This passport belongs to {self.first_name} {self.last_name}, "
                f"born on {self.dob} in {self.country}. It is {validity_str}.")

    def check_data(self, first_name, last_name, dob, country):
        """
        Checks if the provided arguments match the passport's data 
        AND if the passport is still valid.
        """
        # Convert the input dob string to a date object for comparison
        input_dob = date.fromisoformat(dob)
        
        # Check all conditions
        data_matches = (
            self.first_name == first_name and
            self.last_name == last_name and
            self.dob == input_dob and
            self.country == country
        )
        
        return data_matches and self.is_valid()

# You can test your class here
if __name__ == "__main__":
    # Example testing code
    alan = Passport("Alan", "Turing", "1912-06-23", "The United Kingdom", "1954-06-07")
    print(alan.summary())
    print(f"Is valid: {alan.is_valid()}")