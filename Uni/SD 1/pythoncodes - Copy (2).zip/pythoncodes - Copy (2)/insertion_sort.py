def insertion_sort(numbers):
    """
    Sorts a list of numbers using the Insertion Sort algorithm.
    Logic: It builds a sorted section at the left of the list by 
    repeatedly taking the next element and inserting it into 
    the correct position.
    """
    # Start from the second element (index 1) as the first element is "sorted"
    for i in range(1, len(numbers)):
        key = numbers[i]  # The current number we want to insert
        j = i - 1
        
        # Compare the key with elements to its left
        # Move elements of numbers[0..i-1] that are greater than key
        # to one position ahead of their current position
        while j >= 0 and key < numbers[j]:
            numbers[j + 1] = numbers[j]
            j -= 1
            
        # Insert the key into its correct sorted position
        numbers[j + 1] = key
        
    return numbers

if __name__ == "__main__":
    user_input = input("Input your numbers: ")
    
    # Check if the input is empty
    if not user_input.strip():
        print("Please input only numbers!")
    else:
        # Split input and validate that every item is a digit
        raw_items = user_input.split()
        
        # Use a flag to track if all inputs are valid
        is_valid = True
        numbers_list = []
        
        for item in raw_items:
            # We use lstrip('-') to allow for negative numbers if needed
            if item.lstrip('-').isdigit():
                numbers_list.append(int(item))
            else:
                is_valid = False
                break
        
        if is_valid:
            # Run the sorting algorithm
            sorted_list = insertion_sort(numbers_list)
            print("Sorted:")
            print(sorted_list)
        else:
            print("Please input only numbers!")