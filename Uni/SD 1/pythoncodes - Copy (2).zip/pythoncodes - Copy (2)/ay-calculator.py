import datetime

def main():
    # 1. Ask the user for their birthday (Expected format: YYYY-MM-DD)
    birthday_input = input("What is your birthday? ")
    
    # 2. Convert the string into a datetime object
    # fromisoformat() is built specifically for the YYYY-MM-DD format
    birthday_date = datetime.date.fromisoformat(birthday_input)
    
    # 3. Extract the name of the day
    # %A is the format code for the full weekday name (e.g., "Saturday")
    day_name = birthday_date.strftime("%A")
    
    # 4. Print the result
    print(day_name)

if __name__ == "__main__":
    main()