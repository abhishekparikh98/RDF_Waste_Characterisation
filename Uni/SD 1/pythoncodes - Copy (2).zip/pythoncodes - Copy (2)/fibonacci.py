# Function to generate and print n Fibonacci numbers
def fibonacci(n):
    # The first two numbers of the sequence
    a = 1
    b = 1
    
    for i in range(n):
        # Print the current number in the sequence
        print(a)
        
        # Calculate the next number and update our variables
        # 'a' becomes the next number, and 'b' becomes the sum of the two previous
        # Using simultaneous assignment:
        a, b = b, a + b

if __name__ == "__main__":
    user_input = input("Number of Fibonacci Sequence numbers: ")

    # Input Validation
    if user_input.isdigit():
        n_elements = int(user_input)
        
        # Call the function only if n is greater than 0
        if n_elements > 0:
            fibonacci(n_elements)
    else:
        # Triggers if input is text or a negative number
        print("Please input a non-negative integer.")