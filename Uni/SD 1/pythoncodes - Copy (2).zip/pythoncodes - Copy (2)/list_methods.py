# Define the initial list
capitals = ["Amsterdam", "Tokyo", "London", "Cape Town"]

# 1. Print the full list
print(capitals)

# 2. Print the first item of the list (Index 0)
print(capitals[0])

# 3. Add "Paris" to the end and print
capitals.append("Paris")
print(capitals)

# 4. Print range of indexes 1 to 3 (Index 3 is excluded)
print(capitals[1:3])

# 5. Reverse the list and print
capitals.reverse()
print(capitals)

# 6. Add "Cape Town" to the end again and print
capitals.append("Cape Town")
print(capitals)

# 7. Count the number of times "Cape Town" is in the list
print(capitals.count("Cape Town"))

# 8. Remove the first occurrence of "Cape Town"
capitals.remove("Cape Town")

# 9. Print the length of the list
print(len(capitals))

# 10. Add the number 100 to the front (Index 0) and print
capitals.insert(0, 100)
print(capitals)

# 11. Update the first item to "Washington" and print
capitals[0] = "Washington"
print(capitals)