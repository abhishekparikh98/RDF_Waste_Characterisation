# Function to calculate factorial
def factorial(n):
    # We start with 1 because multiplying by 0 would result in 0
    result = 1
    
    # range(1, n + 1) generates numbers from 1 up to (and including) n
    for i in range(1, n + 1):
        result = result * i
        
    return result

if __name__ == "__main__":
    user_input = input("Non-negative integer: ")

    # Validation: 
    # 1. isdigit() ensures it's a number (and handles the "non-negative" part as it rejects "-")
    if user_input.isdigit():
        num = int(user_input)
        
        # Calculate and print the result
        print(factorial(num))
    else:
        # This triggers if input is text or a negative number (e.g., "-5")
        print("Please input a non-negative integer.")