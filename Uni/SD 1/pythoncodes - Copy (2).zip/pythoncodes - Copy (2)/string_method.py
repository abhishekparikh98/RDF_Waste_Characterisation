sentence = "Python is my favorite programming language!"
print(sentence)  # Convert to lowercase
print(sentence.upper())  # Convert to uppercase
print(sentence.count("o"))  # Count occurrences of 'o'
print(sentence.replace("my", "everyone’s"))  # Replace 'favorite' with 'best'
# 5. Print True if all characters are alphabetical (a-z), False if not
# Note: This will be False because the string has spaces and an exclamation mark
print(sentence.isalpha())

# 6. Print True if all characters are ASCII, False if not
print(sentence.isascii())

# 7. Print True if all characters are digits, False if not
print(sentence.isdigit())