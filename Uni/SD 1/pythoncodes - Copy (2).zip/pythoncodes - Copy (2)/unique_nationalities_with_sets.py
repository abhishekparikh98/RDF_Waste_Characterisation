# 1. Define the list of nationalities
nationalities = [
    "United States",
    "Brazil",
    "Germany",
    "Spain",
    "The Netherlands",
    "United States",
    "United States",
    "Australia",
    "Japan",
    "Egypt",
    "South-Africa",
    "South-Korea",
    "China",
    "Japan",
    "Mexico",
    "Germany",
    "Sweden",
    "The Netherlands",
    "Canada"
]

# 2. Cast the list to a set
# This automatically removes all duplicate entries
unique_nationalities = set(nationalities)

# 3. Print the set
print(unique_nationalities)