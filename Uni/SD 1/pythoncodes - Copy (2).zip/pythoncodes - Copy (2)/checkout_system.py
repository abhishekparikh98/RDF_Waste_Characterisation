# Function to add tax with a default value of 15%
def add_percentage(price, percentage=15):
    total = price + (price * (percentage / 100))
    return total

# Function to handle the tip with input validation
def add_tip(price):
    while True:
        tip_input = input("How much tip would you like to give? ")
        if tip_input.isdigit():
            tip_percent = int(tip_input)
            total_with_tip = price + (price * (tip_percent / 100))
            return total_with_tip
        else:
            # Loop continues if input is not a positive integer
            pass

def main():
    # 1. Print the menu using a multiline string
    menu = """1. Habbeer ($3.50)
2. Wine ($4.00)
3. Java Coffee ($2.50)
4. Apple Juice ($6.00)
5. Root Access Beer ($1.75)
"""
    print(menu)

    # 2. Get the order
    order = input("Please write down your order: ")
    
    subtotal = 0.0
    
    # 3. Loop through each character in the input string
    for char in order:
        if char == "1":
            subtotal += 3.50
        elif char == "2":
            subtotal += 4.00
        elif char == "3":
            subtotal += 2.50
        elif char == "4":
            subtotal += 6.00
        elif char == "5":
            subtotal += 1.75

    # 4. Add 15% tax
    price_with_tax = add_percentage(subtotal)

    # 5. Add tip (which asks the user internally)
    final_total = add_tip(price_with_tax)

    # 6. Print final price rounded to 2 decimals
    print(f"\nTotal price: ${final_total:.2f}")

if __name__ == "__main__":
    main()