# Function to filter unique items from a list
def unique_items(lst):
    unique_list = []
    
    # Iterate through every country in the provided list
    for country in lst:
        # Check if the country is already in our unique_list
        # If it is NOT there, we add it
        if country not in unique_list:
            unique_list.append(country)
            
    return unique_list

if __name__ == "__main__":
    # The initial list provided in the task
    nationalities = [
        "United States",
        "Brazil",
        "Germany",
        "Spain",
        "The Netherlands",
        "United States",
        "United States",
        "Australia",
        "Japan",
        "Egypt",
        "South-Africa",
        "South-Korea",
        "China",
        "Japan",
        "Mexico",
        "Germany",
        "Sweden",
        "The Netherlands",
        "Canada"
    ]
    
    # Call the function and store the result
    result = unique_items(nationalities)
    
    # Print the list of unique nationalities
    print(result)