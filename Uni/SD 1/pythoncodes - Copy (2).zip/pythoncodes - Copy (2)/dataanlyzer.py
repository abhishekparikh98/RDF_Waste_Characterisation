def main():
    maximum = None
    minimum = None
    
    while True:
        user_input = input("Input: ")
        
        # Check if the input is a digit
        if user_input.isdigit():
            number = int(user_input)
            
            # If this is the first number, it is both the max and the min
            if maximum is None or minimum is None:
                maximum = number
                minimum = number
            else:
                # Check if the new number is larger than the current max
                if number > maximum:
                    maximum = number
                
                # Check if the new number is smaller than the current min
                if number < minimum:
                    minimum = number
        else:
            # If input is not a digit, stop the loop
            break

    # After the loop finishes, print the results
    if maximum is None:
        print("No integer given.")
    else:
        print(f"Maximum: {maximum}")
        print(f"Minimum: {minimum}")

if __name__ == "__main__":
    main()