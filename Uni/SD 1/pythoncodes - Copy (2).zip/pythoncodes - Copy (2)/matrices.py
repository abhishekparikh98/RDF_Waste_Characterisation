def read_matrix():
    print("Please input your matrix below:")
    matrix = []
    while True:
        line = input()
        # If the user inputs an empty string, we stop reading
        if line == "":
            break
        
        # Split the string by spaces, convert each to int, and make a list (row)
        row = [int(item) for item in line.split()]
        matrix.append(row)
    return matrix

def scalar_multiplication(matrix, scalar):
    result = []
    for row in matrix:
        new_row = []
        for element in row:
            # Multiply each individual number by the scalar
            new_row.append(element * scalar)
        result.append(new_row)
    return result

def transpose(matrix):
    # A matrix has rows and columns. To transpose, we need to know
    # how many rows and columns the ORIGINAL matrix has.
    num_rows = len(matrix)
    num_cols = len(matrix[0])
    
    transposed = []
    # We loop through the original columns to make them the new rows
    for c in range(num_cols):
        new_row = []
        for r in range(num_rows):
            new_row.append(matrix[r][c])
        transposed.append(new_row)
    return transposed

if __name__ == "__main__":
    # 1. Read the matrix from the user
    original_matrix = read_matrix()
    
    if original_matrix:
        # 2. Display the original matrix
        print("Your matrix:")
        print(original_matrix)
        
        # 3. Perform and display scalar multiplication
        print("Scalar multiplication with 8:")
        multiplied = scalar_multiplication(original_matrix, 8)
        print(multiplied)
        
        # 4. Perform and display transposition
        print("Transposition:")
        transposed_matrix = transpose(original_matrix)
        print(transposed_matrix)