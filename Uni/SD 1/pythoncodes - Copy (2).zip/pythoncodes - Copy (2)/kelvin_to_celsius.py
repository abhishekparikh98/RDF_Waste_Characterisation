# 1. Ask the user for input
user_input = input("Temperature in Kelvin: ")

# 2. Input Validation
# .isdigit() checks if the string contains only numbers
if user_input.isdigit():
    # Convert the string to a float for math
    kelvin = float(user_input)
    
    # Perform the calculation
    celsius = kelvin - 273.15
    
    # Print the result
    print(celsius)
else:
    # 3. Fail gracefully if the input is not a number
    print("Please input a digit.")