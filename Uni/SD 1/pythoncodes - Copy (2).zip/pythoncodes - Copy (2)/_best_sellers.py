import numpy as np

def load_dataset(filename):
    """
    Loads the CSV using NumPy's genfromtxt.
    delimiter=',' handles the CSV format.
    dtype=None tells NumPy to guess the data type for each column.
    names=True uses the first row as column headers.
    encoding='utf-8' ensures special characters in book titles are read correctly.
    """
    dataset = np.genfromtxt(filename, delimiter=',', dtype=None, names=True, encoding='utf-8')
    return dataset

def mean_score(dataset):
    """Calculates the average User Rating for all books."""
    # Accessing the named column 'User_Rating'
    mean_rating = np.mean(dataset['User_Rating'])
    return round(mean_rating, 2)

def mean_price(dataset, genre):
    """Calculates the mean price for a specific genre."""
    # Filter the dataset: keep only rows where Genre matches the argument
    genre_mask = dataset['Genre'] == genre
    genre_prices = dataset['Price'][genre_mask]
    
    # Calculate the mean of the filtered prices
    return round(np.mean(genre_prices), 2)

def best_selling_authors(dataset):
    """Returns a dictionary of top 15 authors sorted by frequency."""
    # Get unique authors and their counts
    authors, counts = np.unique(dataset['Author'], return_counts=True)
    
    # argsort returns indices that would sort the array
    # We use flip to make it descending (highest count first)
    sorted_indices = np.flip(np.argsort(counts))
    
    # Take the top 15
    top_15_indices = sorted_indices[:15]
    
    # Build the dictionary
    result = {}
    for i in top_15_indices:
        result[authors[i]] = int(counts[i])
        
    return result

if __name__ == "__main__":
    # Load the data
    data = load_dataset("bestsellers.csv")
    
    # 1. Print Mean Score
    print(mean_score(data))
    
    # 2. Print Mean Price for Fiction and Non Fiction
    print(mean_price(data, "Fiction"))
    # print(mean_price(data, "Non Fiction")) # Optional based on usage
    
    # 3. Print Top 15 Authors
    authors_dict = best_selling_authors(data)
    # Printing the result in a readable way or just the dict as requested
    print(authors_dict)