import csv

# Levenshtein distance algorithm provided in the template
def levenshtein_distance(s1, s2):
    if len(s1) < len(s2):
        return levenshtein_distance(s2, s1)

    if len(s2) == 0:
        return len(s1)

    previous_row = range(len(s2) + 1)
    for i, c1 in enumerate(s1):
        current_row = [i + 1]
        for j, c2 in enumerate(s2):
            insertions = previous_row[j + 1] + 1
            deletions = current_row[j] + 1
            substitutions = previous_row[j] + (c1 != c2)
            current_row.append(min(insertions, deletions, substitutions))
        previous_row = current_row
    
    return previous_row[-1]

def get_text_fingerprint(file_path):
    """Counts alphabetic letters and returns a string sorted by frequency."""
    counts = {}
    with open(file_path, 'r', encoding='utf-8') as f:
        text = f.read().lower()
        for char in text:
            if char.isalpha():
                counts[char] = counts.get(char, 0) + 1
    
    # Sort characters by frequency (descending), then alphabetically if counts are tied
    sorted_chars = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    fingerprint = "".join([char for char, count in sorted_chars])
    return fingerprint

def load_language_data(csv_path):
    """Loads CSV data into a dictionary {Language: Fingerprint}."""
    languages = {}
    with open(csv_path, mode='r', encoding='utf-8') as f:
        # Using csv module to handle the parsing
        reader = csv.reader(f)
        for row in reader:
            if row:
                languages[row[0]] = row[1]
    return languages

def main():
    file_to_analyze = input("Which text file should we analyze? ")
    
    try:
        # 1. Generate fingerprint for the mystery text
        text_fingerprint = get_text_fingerprint(file_to_analyze)
        
        # 2. Load the lookup table
        language_table = load_language_data("letter-frequency-per-language.csv")
        
        best_guess = None
        min_distance = float('inf')
        
        # 3. Compare and print distances
        for language, ref_fingerprint in language_table.items():
            distance = levenshtein_distance(text_fingerprint, ref_fingerprint)
            print(f"{language} {distance}")
            
            if distance < min_distance:
                min_distance = distance
                best_guess = language
        
        print(f"Language detected: {best_guess}")

    except FileNotFoundError:
        print("Error: File not found. Please check your file paths.")

if __name__ == "__main__":
    main()  