def calculate_sd(data_list, average):
    # Step 2 & 3: Sum of squared differences from the mean
    sum_squared_diff = 0
    for grade in data_list:
        sum_squared_diff += (grade - average) ** 2
    
    # Step 4: Variance (average of squared differences)
    variance = sum_squared_diff / len(data_list)
    
    # Step 5: Square root of variance is the Standard Deviation
    sd = variance ** 0.5
    return sd

def main():
    grades = []
    
    # Loop to collect grades
    while True:
        user_input = input("Input: ")
        if user_input.isdigit():
            grades.append(int(user_input))
        else:
            break
            
    # Check if we actually got any numbers
    if len(grades) == 0:
        print("No integer given.")
    else:
        # Calculate characteristics using built-in list functions
        minimum = min(grades)
        maximum = max(grades)
        average = sum(grades) / len(grades)
        
        # Calculate SD using our helper function
        sd = calculate_sd(grades, average)
        
        # Print results
        print(f"Minimum:  {minimum}")
        print(f"Maximum:  {maximum}")
        print(f"Average:  {average}")
        print(f"SD:  {sd}")

if __name__ == "__main__":
    main()