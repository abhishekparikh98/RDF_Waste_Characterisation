import numpy as np
from movie import Movie
from rating import Rating

class MovieDatabase:
    def __init__(self):
        self.movies = []

    def add_movie(self, movie):
        self.movies.append(movie)

    def get_movie_by_name(self, movie_name):
        for movie in self.movies:
            if movie.title == movie_name:
                return movie
        return None

    def movies_by_name(self, partial_movie_name):
        # Return a list of movies containing the partial string
        return [m for m in self.movies if partial_movie_name.lower() in m.title.lower()]

    def add_movies_from_file(self, file_name):
        # Use genfromtxt to read the CSV
        data = np.genfromtxt(file_name, delimiter=',', dtype=None, names=True, encoding='utf-8')
        
        for row in data:
            # Only process if the type is 'Movie'
            if row['type'] == 'Movie':
                title = row['title']
                director = row['director']
                year = int(row['release_year'])
                
                # Logic to convert string ratings from CSV to our Rating Enum
                raw_rating = row['rating']
                if raw_rating == "G":
                    m_rating = Rating.G
                elif raw_rating == "PG-13":
                    m_rating = Rating.PG13
                else:
                    m_rating = Rating.R
                
                new_movie = Movie(title, director, year, m_rating)
                self.add_movie(new_movie)