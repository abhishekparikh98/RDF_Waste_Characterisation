from rating import Rating

class Movie:
    def __init__(self, title, director, year, rating):
        self.title = title
        self.director = director
        self.year = year
        self.rating = rating  # This will be a Rating Enum member

    def can_watch(self, age):
        # The viewer must be older than the minimum age of the rating
        return age > self.rating.value

    def __str__(self):
        return f"{self.title}, directed by {self.director}, released in {self.year}, rated {self.rating.name}."