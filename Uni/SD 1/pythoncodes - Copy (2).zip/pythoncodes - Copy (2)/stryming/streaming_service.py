from movie_database import MovieDatabase
from viewer import Viewer

class StreamingService:
    def __init__(self, name):
        self.name = name
        self.movie_db = MovieDatabase()
        self.customers = []

    def add_customer(self, viewer):
        self.customers.append(viewer)

    def get_movie(self, movie_title):
        return self.movie_db.get_movie_by_name(movie_title)

    def search(self, movie_title):
        results = self.movie_db.movies_by_name(movie_title)
        print(f"Search results for '{movie_title}':")
        for movie in results:
            print(movie)

    def __str__(self):
        return f"Welcome to Streaming Service {self.name}"

if __name__ == "__main__":
    # 1. Create Service
    service = StreamingService("NewNetflix")
    print(service)
    print()

    # 2. Add movies from file
    service.movie_db.add_movies_from_file("netflix_db.csv")

    # 3. Create Viewers
    john = Viewer("John Cleese", 82)
    peter = Viewer("Peter Pan", 12)
    pirate = Viewer("Pirate", 340)

    # 4. Add specific users to customers
    service.add_customer(john)
    service.add_customer(peter)

    # 5. Search for Monty Python
    service.search("Monty Python")
    print()

    # 6. Test watching movies
    def try_watch(viewer, movie_title):
        movie = service.get_movie(movie_title)
        if movie:
            if movie.can_watch(viewer.age):
                print(f"Watching {movie}")
            else:
                print(f"{viewer} cannot watch this movie!")
        else:
            print(f"Movie '{movie_title}' not found.")

    try_watch(john, "Monty Python and the Holy Grail")
    print()
    try_watch(peter, "Monty Python and the Holy Grail")
    print()
    try_watch(pirate, "The Pirate Fairy")