# Function to convert Kelvin to Celsius
def kelvin_to_celsius(temperature):
    celsius = temperature - 273.15
    return celsius

# Function to convert Kelvin to Fahrenheit
def kelvin_to_fahrenheit(temperature):
    # Formula: F = (K − 273.15) * 9/5 + 32
    fahrenheit = (temperature - 273.15) * 9/5 + 32
    return fahrenheit

# The execution block
if __name__ == "__main__":
    user_input = input("Temperature in Kelvin: ")

    # Input Validation
    if user_input.isdigit():
        # Convert input string to a number
        k_temp = float(user_input)
        
        # Call the functions and print the results
        print(kelvin_to_celsius(k_temp))
        print(kelvin_to_fahrenheit(k_temp))
    else:
        print("Please input a digit.") 