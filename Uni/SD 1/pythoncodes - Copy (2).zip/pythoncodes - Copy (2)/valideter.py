password = input("Your password: ")

# 1. Check for common keywords
if "password" in password or "123456" in password:
    print("The password may not contain the keywords “password” or “123456”.")

# 2. Check if it starts with "qwerty"
elif password.startswith("qwerty"):
    print("The password may not start with the keyword “qwerty” but it may contain it.")

# 3. Check for at least one non-alphabetic character (numbers or symbols)
elif password.isalpha():
    print("The password must contain at least one non-alphabetic character.")

# 4. Check for at least one non-digit character (letters or symbols)
elif password.isdigit():
    print("The password must contain at least one non-digit character.")

# 5. Check for special characters: $, @, or !
elif not ("$" in password or "@" in password or "!" in password):
    print("The password must contain at least one of the following special characters: $, @ or !.")

# 6. Check for both uppercase and lowercase
elif password.islower() or password.isupper():
    print("The password must have both uppercase and lowercase letters.")

# If all checks pass
else:
    print("The password is valid!")