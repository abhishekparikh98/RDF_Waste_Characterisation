# 1. Ask the user for a binary string or number
user_input = input("Your input number: ")

# 2. Input Validation (Bonus points part)
if user_input.isdigit():
    # Convert input string to an integer
    number = int(user_input)
    
    # 3. Check the Parity (Evenness)
    # If the remainder when divided by 2 is 0, the number is even
    if number % 2 == 0:
        print("OK!")
    else:
        print("Error detected!")
else:
    # Exit gracefully if input is not a digit
    print("Please input a digit.")