def main():
    # 1. Define punctuation to strip
    punctuation = ",:‘.!?"
    word_counts = {}

    try:
        # 2. Open and read the sonnets file
        with open("sonnets.txt", "r", encoding="utf-8") as file:
            for line in file:
                # Split line into words
                words = line.split()
                
                for word in words:
                    # 3. Clean the word: lowercase and strip punctuation/whitespace
                    clean_word = word.lower().strip(punctuation).strip()
                    
                    # Skip empty strings (e.g., if a word was just punctuation)
                    if not clean_word:
                        continue
                    
                    # 4. Update the dictionary count
                    if clean_word in word_counts:
                        word_counts[clean_word] += 1
                    else:
                        word_counts[clean_word] = 1

        # 5. Sort the dictionary by frequency (the value) in descending order
        # word_counts.items() returns pairs of (word, count)
        # key=lambda item: item[1] tells sorted() to look at the count
        sorted_words = sorted(word_counts.items(), key=lambda item: item[1], reverse=True)

        # 6. Print the 50 most common words
        print("The 50 most common words by Shakespeare:")
        for i in range(min(50, len(sorted_words))):
            word, count = sorted_words[i]
            print(f"{word} {count}")

    except FileNotFoundError:
        print("Error: sonnets.txt not found. Please ensure the file is in the same directory.")

if __name__ == "__main__":
    main()