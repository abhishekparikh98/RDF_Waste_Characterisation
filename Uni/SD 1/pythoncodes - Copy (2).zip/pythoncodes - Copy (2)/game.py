import random
from enum import Enum

# Define Enums for Actions and Results
class Action(Enum):
    ROCK = 0
    PAPER = 1
    SCISSORS = 2

class Result(Enum):
    WIN = 0
    DRAW = 1
    LOSS = 2

class Player:
    def __init__(self, name):
        self.name = name
        self.score = 0

    def increase_score(self):
        self.score += 1

    def reset_score(self):
        self.score = 0

    def play(self):
        """Asks the user for input and converts it to an Action Enum."""
        while True:
            choice = input("What will be your action [rock / paper / scissors]? ").lower()
            if choice == "rock":
                return Action.ROCK
            elif choice == "paper":
                return Action.PAPER
            elif choice == "scissors":
                return Action.SCISSORS
            print("Invalid input! Try again.")

    def __str__(self):
        return f"Player {self.name} has {self.score} points."

class Bot(Player):
    def __init__(self):
        # Use super to initialize with the name "Bot"
        super().__init__("Bot")

    def play(self):
        """Overrides play to choose a random Action."""
        return random.choice(list(Action))

class RockPaperScissors:
    def __init__(self, player1, player2, goal):
        self.p1 = player1
        self.p2 = player2
        self.goal = goal

    def get_round_result(self, action1, action2):
        """Determines if p1 wins, draws, or loses against p2."""
        if action1 == action2:
            return Result.DRAW
        
        # Logic for P1 Winning
        if (action1 == Action.ROCK and action2 == Action.SCISSORS) or \
           (action1 == Action.PAPER and action2 == Action.ROCK) or \
           (action1 == Action.SCISSORS and action2 == Action.PAPER):
            return Result.WIN
        
        return Result.LOSS

    def reset(self):
        self.p1.reset_score()
        self.p2.reset_score()

    def start(self):
        """The main game loop."""
        while self.p1.score < self.goal and self.p2.score < self.goal:
            a1 = self.p1.play()
            a2 = self.p2.play()
            
            result = self.get_round_result(a1, a2)
            
            if result == Result.WIN:
                print(f"{self.p1.name} won this round!")
                self.p1.increase_score()
            elif result == Result.LOSS:
                print(f"{self.p2.name} won this round!")
                self.p2.increase_score()
            else:
                print("The round was a draw!")
            
            print(self.p1)
            print(self.p2)
            print() # Newline for readability

        # Determine overall winner
        winner = self.p1.name if self.p1.score == self.goal else self.p2.name
        print(f"The game has ended! Player {winner} won!")

if __name__ == "__main__":
    # Setup
    user_name = input("Enter your name: ")
    human = Player(user_name)
    bot = Bot()
    
    # Initialize game with a goal of 5 points
    game = RockPaperScissors(human, bot, 5)
    game.start()