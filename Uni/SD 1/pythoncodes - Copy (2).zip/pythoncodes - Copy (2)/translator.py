def main():
    # 1. Define the English to German dictionary
    english_to_german = {
        "good day": "Guten Tag!",
        "good morning": "Guten Morgen!",
        "goodbye": "Auf Wiedersehen!",
        "how are you": "Wie geht's?",
        "my name is python": "Mein Name ist Python!",
        "do you speak english": "Sprechen sie Englisch?",
        "where is the bathroom": "Wo ist die Toilette?",
        "thank you": "Danke!",
        "i am sorry": "Es tut mir leid!",
        "a large beer please": "Ein grosses Bier, bitte!"
    }

    # 2. Prompt user for input
    user_input = input("English sentence to translate: ")

    # 3. Process the sentence:
    # We create a new string containing only letters and spaces, then lowercase it
    cleaned_sentence = ""
    for char in user_input:
        if char.isalpha() or char == " ":
            cleaned_sentence += char
    
    cleaned_sentence = cleaned_sentence.lower()

    # 4. Translate the sentence
    # Check if the cleaned sentence exists as a key in our dictionary
    if cleaned_sentence in english_to_german:
        print(english_to_german[cleaned_sentence])
    else:
        print("No translation found!")

if __name__ == "__main__":
    main()