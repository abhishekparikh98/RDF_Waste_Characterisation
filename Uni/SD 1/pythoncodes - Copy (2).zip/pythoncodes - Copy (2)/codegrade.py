from datetime import datetime

class CodeGradeUser:
    def __init__(self, username, institute):
        self.username = username
        self.institute = institute

    def hello(self):
        print(f"Hello {self.username} from {self.institute}!")

class Student(CodeGradeUser):
    def __init__(self, username, institute, graduation_year):
        # super() calls the Parent class's __init__ to handle username and institute
        super().__init__(username, institute)
        self.graduation_year = graduation_year

    def graduated(self):
        current_year = datetime.now().year
        # Returns True if the current year is greater than or equal to graduation year
        return current_year >= self.graduation_year

    def handin(self, assignment):
        if not self.graduated():
            print(f"Thanks, {self.username}! Your submission {assignment} was successfully handed in!")
        else:
            print(f"Sorry {self.username}, you can only hand in if you haven't graduated yet!")

class Teacher(CodeGradeUser):
    def teach(self):
        return "Python is named after the British comedy troupe Monty Python."

    def grade(self, student_obj, grade_value):
        # We check if the teacher's institute matches the student's institute
        if self.institute == student_obj.institute:
            print(f"Teacher {self.username} graded {student_obj.username} with grade {grade_value}.")
        else:
            print(f"You cannot grade {student_obj.username} as they are from another institute.")

# Testing the implementation
if __name__ == "__main__":
    # You can replicate the example usage here to verify
    robin = Teacher("Robin", "Code University")
    peter = Student("Peter", "Code University", 2026)
    devin = Student("Devin", "University of Amsterdam", 2018)

    robin.hello()
    robin.grade(peter, 85)
    robin.grade(devin, 90)